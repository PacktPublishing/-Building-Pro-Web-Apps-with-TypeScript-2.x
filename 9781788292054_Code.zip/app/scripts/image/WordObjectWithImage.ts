import { getImageSource } from "image/IImage";
export class WordObjectWithImage extends getImageSource() {
    public constructor() {
        super();
    }
}

