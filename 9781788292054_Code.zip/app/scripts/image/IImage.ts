import { CdnImage } from "image/CdnImage";
import { ServerImage } from "image/ServerImage";

export interface IImage {
    source: string;
    getBytes: () => string
}

export interface IImageConstructor {
    new (): IImage;
}

export function getImageSource(): IImageConstructor {
    const randomValue = Math.random();
    console.log(randomValue);
    return randomValue >= 0.5 ? CdnImage : ServerImage;
}
