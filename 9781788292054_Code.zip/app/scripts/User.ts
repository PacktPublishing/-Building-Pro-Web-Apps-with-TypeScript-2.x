export class User implements NamingObject {
    name: string;
    public setName: (name: string) => void;
    public getName: () => string;
}

export class NamingObject {
    name: string;
    public setName(name: string): void {
        this.name = name;
    }
    public getName(): string {
        return this.name;
    }
}

export class NamingObject2 {
    name: string;
    public setName(name: string): void {
        this.name = name + " " + name;
    }
    public getName(): string {
        return this.name;
    }
}