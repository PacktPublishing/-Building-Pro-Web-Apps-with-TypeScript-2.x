import { Favorite } from "favorite/Favorite";

export type WithTimestamp = new (...args: any[]) => object;

export function Timestamped<BC extends WithTimestamp>(Base: BC) {
    return class extends Base {
        private timestampData = new Date();
        get timestamp() {
            return this.timestampData;
        }
    };
}

export class FavoriteWithTimeStamp extends Timestamped(Favorite) {
    constructor() {
        super();
    }
}
