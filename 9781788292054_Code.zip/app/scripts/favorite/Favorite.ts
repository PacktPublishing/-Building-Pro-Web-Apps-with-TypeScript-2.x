import { IUniqueObject } from "general/IUniqueObject";
import { IWord } from "word/IWord"
export class Favorite<T extends IUniqueObject = IWord>{
    private list: {
        [K: string]: T;
    };
    public constructor() {
        this.list = {};
    }
    public addFavorite(fav: T): void {
        this.list[fav.id] = fav;
    }
    public getAllFavorites(): T[] {
        const list: T[] = [];
        for (const key in this.list) {
            if (this.list.hasOwnProperty(key)) {
                const value = this.list[key];
                list.push(value);
            }
        }
        return list;
    }
    public toggleFavorite(fav: T): void {
        if (this.hasFavorite(fav)) {
            delete this.list[fav.id];
        } else {
            this.addFavorite(fav);
        }
    }
    public hasFavorite(fav: T): boolean {
        return (typeof this.list[fav.id] !== "undefined");
    }
}