import { Game } from "Game";
import { Favorite } from "favorite/Favorite";
import { IUniqueObject } from "./general/IUniqueObject";
import { IWord } from "word/IWord";
import { IWordContext, IFlashCardContext } from "word/IWordContext";
export class GameTurnBased extends Game {
    private favorite: Favorite<IUniqueObject>;
    constructor() {
        super();
        this.favorite = new Favorite<IUniqueObject>();
    }

    public buildGameContext(word: IWord): IFlashCardContext {
        const defaultContext = super.buildGameContext(word);
        const turnBasedContext = {
            toggleFavorite: (obj: IUniqueObject) => {
                this.favorite.toggleFavorite(obj);
                this.notifyGameChange();
            },
            isFavorited: (obj: IUniqueObject) => this.favorite.hasFavorite(obj)
        } as IFlashCardContext;
        const mergedContext = { ...defaultContext, ...turnBasedContext } as IFlashCardContext;
        return mergedContext;
    }
}