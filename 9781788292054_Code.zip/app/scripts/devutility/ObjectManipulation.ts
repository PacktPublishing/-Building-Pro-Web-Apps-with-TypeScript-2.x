export type Stringify<T> = {
    [P in keyof T]: string;
};

export function transformAllIntoString<T>(obj: T): Stringify<T> {
    let r: Stringify<T> = {} as Stringify<T> ;
    Object.keys(obj).forEach(key => {
        r[key] = obj[key] + "";
    });
    return r;
}