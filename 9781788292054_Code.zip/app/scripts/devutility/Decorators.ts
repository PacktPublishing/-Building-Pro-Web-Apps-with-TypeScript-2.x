import "reflect-metadata";

export function countinstance<T extends { new (...args: any[]): {} }>(constructor: T) {
    const x = class extends constructor {
        public static instanceCount = 0;

        constructor(...args: any[]) {
            super();
            x.instanceCount++;
            console.log("Count = " + x.instanceCount);
        }
    }

    return x;
}

export function autobind(target, key, descriptor) {
    const fn = descriptor.value;

    if (typeof fn !== "function") {
        throw new Error(`@autobind on method only, not on : ${typeof fn}`);
    }

    // In IE11 calling Object.defineProperty has a side-effect of evaluating the
    // getter for the property which is being replaced. This causes infinite
    // recursion and an "Out of stack space" error.
    let definingProperty = false;

    return {
        configurable: true,
        get() {
            if (definingProperty || this === target.prototype || this.hasOwnProperty(key)) {
                return fn;
            }

            const boundFn = fn.bind(this);
            definingProperty = true;
            Object.defineProperty(this, key, {
                value: boundFn,
                configurable: true,
                writable: true
            });
            definingProperty = false;
            return boundFn;
        }
    };
}

export function capitalize() {
    return (target: any, propertyKey: string, descriptor: PropertyDescriptor) => {
        const originalGet = descriptor.get;
        // Cannot be arrow function, we need the "this" from the caller
        descriptor.get = function () {
            return (() => {
                const valueFromOriginal = originalGet.call(this) as string;
                return valueFromOriginal.toUpperCase();
            })();
        };
    };
}


const formatMetadataKey = Symbol("format");
export function format(formatString: string) {
    return Reflect.metadata(formatMetadataKey, formatString);
}

export function getFormat(target: any, propertyKey: string) {
    return Reflect.getMetadata(formatMetadataKey, target, propertyKey);
}




const notnullMetadataKey = Symbol("notnull");

export function notnull(target: Object, propertyKey: string | symbol, parameterIndex: number) {
    let existingRequiredParameters: number[] = Reflect.getOwnMetadata(notnullMetadataKey, target, propertyKey) || [];
    existingRequiredParameters.push(parameterIndex);
    Reflect.defineMetadata(notnullMetadataKey, existingRequiredParameters, target, propertyKey);
}

export function validatenotnull(target: any, propertyName: string, descriptor: TypedPropertyDescriptor<Function>) {
    const originalMethod = descriptor.value;
    descriptor.value = function (...args: any[]) {
        const requiredParameters: number[] = Reflect.getOwnMetadata(notnullMetadataKey, target, propertyName);
        if (requiredParameters) {
            for (const parameterIndex of requiredParameters) {
                const valueOfParameter = args[parameterIndex];
                if (valueOfParameter === undefined || valueOfParameter === null) {
                    const types = Reflect.getMetadata("design:paramtypes", target, propertyName) as object[];
                    throw new Error("Missing required argument name at index '" + parameterIndex + "' of type '" + types[parameterIndex].toString() + "'. Value is '" + valueOfParameter + "'.");
                }
            }
        }

        return originalMethod.apply(this, args);
    }
}