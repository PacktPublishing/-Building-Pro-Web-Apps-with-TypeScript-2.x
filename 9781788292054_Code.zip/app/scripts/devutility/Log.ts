import { Animal } from "word/Animal";
import { Vehicule } from "word/Vehicule";
import { ObjectWithoutSound } from "word/ObjectWithoutSound";

export class Log {
    public debug(obj: Animal | Vehicule | ObjectWithoutSound): void {
        console.log(obj.word + " id is " + obj.id);

        if ((this.isAnimal(obj))) {
            console.log("Animal with " + obj.numberLegs + " legs");
        } else if (obj instanceof Vehicule) {
            console.log("Vehicule with " + obj.numberOfWheel + " wheels");
        } else if (obj instanceof ObjectWithoutSound) {
            console.log("ObjectWithoutSound");
        }
    }

    public isAnimal(obj: any): obj is Animal {
        return obj !== undefined;
    }

    // Object [[object Object]].word: Test1 of type string
    public debugByPropertyWithKey<T, K extends keyof T>(obj: T, key: K): void {
        console.log("Object [" + obj + "]." + key + ": " + obj[key] + " of type " + typeof obj[key]);
    }
}