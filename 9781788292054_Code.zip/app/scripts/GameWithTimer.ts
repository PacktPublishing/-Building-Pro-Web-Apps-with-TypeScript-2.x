import { Game } from "Game";
import { Favorite } from "favorite/Favorite";
import { IUniqueObject } from "./general/IUniqueObject";
import { IWord } from "word/IWord";
import { IWordContext, IFlashCardContext } from "word/IWordContext";
import { FavoriteWithTimeStamp } from "favorite/Timestamped";
type TimeMs = number | (() => number);
type FavoriteWithTime<T extends IUniqueObject> = Favorite<T> & FavoriteWithTimeStamp; 
export class GameWithTimer extends Game {
    private favorite: FavoriteWithTime<IUniqueObject>; 
    private ms: TimeMs;
    private idTimer: number;
    constructor(ms: TimeMs) { 
        super();
        this.favorite = this.createFavoriteWithTime(new Favorite<IUniqueObject>());
        this.ms = ms;
        const time = this.getTime(ms);
        this.idTimer = window.setInterval(() => {
            this.nextWord();
        }, time);
    }
    private createFavoriteWithTime<T extends IUniqueObject>(fav: Favorite<T>): FavoriteWithTimeStamp {
        return new FavoriteWithTimeStamp();
    }

    private getTime(ms: TimeMs): number {
        return (typeof ms === "function") ? ms() : ms;
    }

    public buildGameContext(word: IWord): IFlashCardContext {
        const defaultContext = super.buildGameContext(word);
        const turnBasedContext = {
            toggleFavorite: (obj: IUniqueObject) => {
                this.favorite.toggleFavorite(obj);
                this.notifyGameChange();
            },
            isPreviousButtonEnabled: false,
            isNextButtonEnabled: false,
            isFavorited: (obj: IUniqueObject) => this.favorite.hasFavorite(obj)
        } as IFlashCardContext;

        const mergedContext = { ...defaultContext, ...turnBasedContext } as IFlashCardContext;
        return mergedContext;
    }
}