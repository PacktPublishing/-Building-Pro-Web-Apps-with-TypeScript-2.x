import { WordObject } from "word/WordObject";
export class ObjectWithSound extends WordObject {
    public soundFile: string;
}