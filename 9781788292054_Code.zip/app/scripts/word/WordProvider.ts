export class WordProvider {
    public static getWords(): Promise<string> {

        return WordProvider.delay(1000).then(() => {
            const deferredResult: Promise<string> = new Promise<string>((resolve: (c: string) => void, reject: (any) => void) => {
                $.ajax({
                    url: "http://localhost:8080/files/words/list.txt",
                    success: c => {
                        resolve(c);
                    }, error: (e, errorMessage) => {
                        const rej = { message: errorMessage };
                        reject(rej);
                    }
                });
            });
            return deferredResult;
        });
    }

    public static delay(ms: number): Promise<void> {
        return new Promise<void>((resolve, reject) => {
            setTimeout(resolve, ms);
            //setTimeout(reject, ms);
        });
    }
}