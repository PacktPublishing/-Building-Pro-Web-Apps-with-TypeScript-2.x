
import { ObjectWithSound } from "word/ObjectWithSound";
import { countinstance } from "../devutility/Decorators";
@countinstance
export class Animal extends ObjectWithSound {
    public numberLegs: number;

    constructor(numberOfLegs:number = 4) {
        super();
        this.numberLegs = numberOfLegs;
    }
}