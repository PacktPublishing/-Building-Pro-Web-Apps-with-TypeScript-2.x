import { IUniqueObject } from "general/IUniqueObject";
import { IImage } from "image/IImage";
import { WordObjectWithImage } from "image/WordObjectWithImage";
export interface IWord extends IUniqueObject {
    word: string;
    firstLetter: string;
    image:WordObjectWithImage;
}