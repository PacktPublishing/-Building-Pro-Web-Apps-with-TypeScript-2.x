import { IWord } from "word/IWord";
import { IUniqueObject } from "general/IUniqueObject";

export interface IWordContext {
    word: IWord;
    // Base index 1
    currentWordPosition: number;
    // Base index 1
    totalNumberOfWord: number;
}

export interface IFavoriteContext extends IWordContext {
    toggleFavorite: (obj: IUniqueObject) => void;
    isFavorited: (obj: IUniqueObject) => boolean;
}

export interface IHeaderContext extends IFavoriteContext {
}

export interface IFooterContext extends IWordContext {
    previousWord: () => void;
    nextWord: () => void;
    isPreviousButtonEnabled: boolean;
    isNextButtonEnabled: boolean;
}

export interface IFlashCardContext extends IWordContext, IHeaderContext, IFooterContext {

}