
import { ObjectWithSound } from "word/ObjectWithSound";

export class Vehicule extends ObjectWithSound {
    public numberOfWheel: number;
    public constructor(){
        super();
    }
}