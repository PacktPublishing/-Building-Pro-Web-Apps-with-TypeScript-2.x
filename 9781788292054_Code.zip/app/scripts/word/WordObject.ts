import { IWord } from "word/IWord";
import { IImage } from "image/IImage";
import { WordObjectWithImage } from "image/WordObjectWithImage";
import { Guid } from "general/Guid";
import { capitalize, getFormat, format } from "../devutility/Decorators";
export abstract class WordObject implements IWord {
    @format("The word is : %s")
    public word: string;
    public firstLetter: string;
    public image: WordObjectWithImage;
    public id: string;
    public constructor(id?: string) {
        if (id) {
            this.id = id
        } else {
            this.id = Guid.newGuid();
        }
        this.image = new WordObjectWithImage();
    }

    @capitalize()
    public get formattedWord(): string {
        return this.word;
    }

    public getFormattedWordWithDecoratorFormat(): string {
        const formatString = getFormat(this, "word");
        return formatString.replace("%s", this.word);
    }
}