﻿import { GameTurnBased } from "GameTurnBased";
import { AppUi } from "ui/AppUi";
import { IWord } from "word/IWord";
import { WordObject } from "word/WordObject";
import { Animal } from "./word/Animal";
import { ObjectWithoutSound } from "./word/ObjectWithoutSound";
import { Vehicule } from "./word/Vehicule";
import { User, NamingObject, NamingObject2 } from "User";
import { GameWithTimer } from "GameWithTimer";
import { Log } from "devutility/Log";
import { transformAllIntoString } from "devutility/ObjectManipulation";
import { WordProvider } from "./word/WordProvider";
import { Game } from "./Game";

applyMixins(User, [NamingObject]);
const game = new GameTurnBased();
const appUi = new AppUi($("#game-container"), game);


// Initial list
const listWords = [
    null,
    createObject("Apple"),
    createObject("Banana"),
    createObject("Grape"),
    createObject("Kiwi"),
    createObject("Pear"),
    createAnimal("Dog", 4),
    createAnimal("Bird", 2),
    createAnimal("Cat", 4),
    createVehicule("Car", 2),
    createVehicule("Motocycle", 2),
    createVehicule("Unicycle", 1)
];
game.startNewGame(listWords);
game.addWords(createObject("Test1"));
game.addWords(...[createObject("Test2"), createObject("Test3")])

const log = new Log();
const objToLog = createObject("Test1");
log.debugByPropertyWithKey(objToLog, "word");

const str = transformAllIntoString(objToLog);
console.log("Object:"+objToLog);
console.log("Object transformed:"+str);


function createObject(data: string): ObjectWithoutSound {
    const c = new ObjectWithoutSound();
    c.word = data;
    c.firstLetter = data[0];
    c.image.source = "files/images/objects/" + c.word + ".png";
    return c;
}

function createAnimal(data: string, numberLegs: number): Animal {
    const c = new Animal();
    c.word = data;
    c.firstLetter = data[0];
    c.numberLegs = numberLegs;
    c.soundFile = data + "-animal.mp3";
    c.image.source = "files/images/animals/" + c.word + ".png";
    return c;
}

function createVehicule(data: string, numberOfWheel: number): Vehicule {
    const c = new Vehicule();
    c.word = data;
    c.firstLetter = data[0];
    c.soundFile = data + "-vehicule.mp3";
    c.numberOfWheel = numberOfWheel;
    c.image.source = "files/images/vehicules/" + c.word + ".png";
    return c;
}

function applyMixins(derivedCtor: any, baseCtors: any[]) {
    baseCtors.forEach(baseCtor => {
        Object.getOwnPropertyNames(baseCtor.prototype).forEach(name => {
            derivedCtor.prototype[name] = baseCtor.prototype[name];
        });
    });
}


const wordsInString = WordProvider.getWords()
    .then((value: string) => {
        const arrayWords = value.split(/\r/g);
        arrayWords.forEach((w) => {
            game.addWord(createObject(w));
        });
    })
    .catch((reason: any) => { console.error("Getting words was problematic because of : " + reason.message) });

const wordsInString2 = getWordsAsync()
console.log("3- getWords has been called");

async function getWordsAsync(): Promise<string[]> {
    console.log("getWords 1 - We will wait the promise to be fulfilled");
    try {
        const words = await WordProvider.getWords();
        console.log("getWords 2 - Promise fulfilled");
        const arrayWords = words.split(/\r/g);
        arrayWords.forEach((w) => {
            game.addWord(createObject(w));
        });
        return arrayWords;
    } catch (e) {
        return null;
    }
}
console.log("END");




(<any>Symbol).asyncIterator = Symbol.asyncIterator || Symbol.for("Symbol.asyncIterator");

function delay(ms: number): Promise<void> {
    return new Promise<void>((resolve) => {
        setTimeout(resolve, ms);
    });
}

function randomWord(): ObjectWithoutSound {
    const random = 3 + Math.floor(Math.random() * 5);
    let wordString = "";
    for (let i = 0; i < random; i++) {
        const letter = 97 + Math.floor(Math.random() * 26);
        wordString += String.fromCharCode(letter);
    }
    return createObject(wordString);
}
let i = 0;
async function* getRandomWords(): any {
    while (i<100) {
        yield randomWord();
        //await delay(1000);
        yield* [randomWord(), randomWord()];
        i++;
    }
}

async function addWordsAsynchronously(game: Game) {
    for await (const x of getRandomWords()) {
        console.log("Iterator loop:" + (x as ObjectWithoutSound).word);
        game.addWord(x);
    }
}

addWordsAsynchronously(game);