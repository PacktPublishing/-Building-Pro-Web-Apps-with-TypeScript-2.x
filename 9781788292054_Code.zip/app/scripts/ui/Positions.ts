import { Component } from "ui/Component";
import { IWordContext } from "word/IWordContext";
export class Positions extends Component<IWordContext> {
    public renderImplementation(): JQuery {
        const value = super.getValue();
        const $mainContainer = $("<div>");
        $mainContainer.addClass("positions");
        if (value) {
            $mainContainer.append(value.currentWordPosition.toString());
            $mainContainer.append("/");
            $mainContainer.append(value.totalNumberOfWord.toString());
        }
        return $mainContainer;
    }
}