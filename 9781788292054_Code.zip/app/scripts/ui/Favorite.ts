import { Component } from "ui/Component";
import { IFavoriteContext } from "word/IWordContext";
import { autobind } from "../devutility/Decorators";
export class Favorite extends Component<IFavoriteContext> {
    public renderImplementation(): JQuery {
        const $mainContainer = $("<div>");
        $mainContainer.addClass("favorite");
        const $btnFavorite = $("<span>");
        $btnFavorite.addClass("btn");
        const e = this.getValue();
        if (this.getValue().isFavorited(e.word)) {
            $btnFavorite.append("🌟");
        } else {
            $btnFavorite.append("⭐️");
        }
        $mainContainer.append($btnFavorite);
        $btnFavorite.click(this.favoriteClick);
        return $mainContainer;
    } 
    
    @autobind
    private favoriteClick(): void {
        const data = this.getValue();
        data.toggleFavorite(data.word);
    }

}