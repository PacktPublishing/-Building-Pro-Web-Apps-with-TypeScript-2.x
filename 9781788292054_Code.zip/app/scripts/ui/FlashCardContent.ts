import { Component } from "ui/Component";
import { IWordContext } from "word/IWordContext";
import { ObjectWithSound } from "word/ObjectWithSound";
export class FlashCardContent extends Component<IWordContext> {
    public renderImplementation(): JQuery {
        const c: IWordContext = super.getValue();
        const $mainContainer = $("<div>");
        $mainContainer.addClass("flashcard-content");

        this.addWord(c, $mainContainer);
        this.addFirstLetter(c, $mainContainer);
        this.addImage(c, $mainContainer);
        this.addWordSound(c, $mainContainer);
        this.addSound(c, $mainContainer);

        return $mainContainer;
    }

    private addImage(c: IWordContext, $mainContainer: JQuery): void {
        const $imageWord = $("<div>");
        $imageWord.addClass("content-image-word");
        if (c.word.image) {
            const $imageWordImg = $("<img>");
            const bytes = c.word.image.getBytes();
            $imageWordImg.attr("src", c.word.image.getBytes());
            $imageWordImg.attr("data-source", c.word.image.source);
            $imageWordImg.attr("data-bytes", bytes);
            $imageWordImg.attr("title", bytes);
            $imageWord.append($imageWordImg);
        }
        $mainContainer.append($imageWord);
    }

    private addSound(c: IWordContext, $mainContainer: JQuery): void {
        if (c.word instanceof ObjectWithSound) {
            const soundFile = c.word.soundFile;
            const $imageSoundWord = $("<div>");
            $imageSoundWord.addClass("content-image-sound");
            const $soundWordSound2 = $("<span>");
            $soundWordSound2.addClass("btn");
            $soundWordSound2.text("🔊");
            $soundWordSound2.attr("title", soundFile);
            $imageSoundWord.append($soundWordSound2);
            $mainContainer.append($imageSoundWord);
        }
    }

    private addFirstLetter(c: IWordContext, $mainContainer: JQuery): void {
        const $firstLetterDiv = $("<div>");
        $firstLetterDiv.addClass("content-first-letter");
        $firstLetterDiv.text(c.word.firstLetter);
        $mainContainer.append($firstLetterDiv);
    }

    private addWord(c: IWordContext, $mainContainer: JQuery): void {
        const $wordsDiv = $("<div>");
        $wordsDiv.addClass("content-word");
        $wordsDiv.text(c.word.word);
        $mainContainer.append($wordsDiv);
    }

    private addWordSound(c: IWordContext, $mainContainer: JQuery): void {
        const $soundWord = $("<div>");
        $soundWord.addClass("content-sound");
        const $soundWordSound = $("<span>");
        $soundWordSound.addClass("btn");
        $soundWordSound.text("🔊");
        $soundWord.append($soundWordSound);
        $mainContainer.append($soundWord);
    }
}