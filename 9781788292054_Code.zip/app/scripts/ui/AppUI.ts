import { FlashCard } from "ui/FlashCard";
import { FlashCardHeader } from "ui/FlashCardHeader";
import { FlashCardContent } from "ui/FlashCardContent";
import { FlashCardFooter } from "ui/FlashCardFooter";
import { Favorite } from "ui/Favorite";
import { Positions } from "ui/Positions";
import { Component } from "ui/Component";
import { Game } from "Game";
import { IWordContext, IFlashCardContext } from "word/IWordContext";
import { IUniqueObject } from "general/IUniqueObject";
import { GameTurnBased } from "GameTurnBased";
import { User } from "User";

export class AppUi {
    private flashCard: FlashCard;
    private flashCardFooter: FlashCardFooter;
    private flashCardContent: FlashCardContent;
    private flashCardHeader: FlashCardHeader;
    private positions: Positions;
    private favorite: Favorite;
    private user: User;
    public constructor(private $container: JQuery, private game: Game) {
        this.bootstrapComponents();
        this.bootstrapEvents();
        this.user = new User();
        this.user.setName("Tester");
        console.log(this.user.getName());
    }

    private bootstrapComponents(): void {
        this.favorite = new Favorite();
        this.positions = new Positions();
        this.flashCardHeader = new FlashCardHeader(this.favorite, this.positions);
        this.flashCardContent = new FlashCardContent();
        this.flashCardFooter = new FlashCardFooter();
        this.flashCard = new FlashCard(this.flashCardHeader, this.flashCardContent, this.flashCardFooter);
    }

    private bootstrapEvents(): void {
        this.game.onGameChanged = this.renderCallBackWithMap;
        this.game.onGameStarted = this.renderStartCallBack;
        this.game.onGameEnded = this.renderEndCallBack;
    }

    private renderCallBackWithMap = (data: IFlashCardContext) => {
        this.render(data);
    };

    private renderStartCallBack = () => {
        this.$container.html("Start");
    };

    private renderEndCallBack = () => {
        this.$container.html("End");
    };
    private render(data: IFlashCardContext): void {
        const $flashCardRender = this.flashCard.render(data);
        if (this.$container.html() === "") {
            // First render
            this.$container.append($flashCardRender);
        } else {
            // All update render (after first)
            this.$container.children().replaceWith($flashCardRender);
        }
    }

}
