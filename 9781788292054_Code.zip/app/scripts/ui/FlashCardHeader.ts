import { Component } from "ui/Component";
import { Favorite } from "Favorite";
import { Positions } from "Positions";
import { IWordContext, IHeaderContext } from "word/IWordContext";

export class FlashCardHeader extends Component<IHeaderContext> {
    public constructor(private favorite: Favorite, private positions: Positions)
    {
        super();
    }
    public renderImplementation(): JQuery {
        const data = this.getValue();
        const $mainContainer = $("<div>");
        $mainContainer.addClass("flashcard-header");
        $mainContainer.append(this.positions.render(data));
        if (data.toggleFavorite !== null && data.toggleFavorite !== undefined) {
            $mainContainer.append(this.favorite.render(data));
        }
        return $mainContainer;
    }
}