export interface IUniqueObject {
    id: string;
}