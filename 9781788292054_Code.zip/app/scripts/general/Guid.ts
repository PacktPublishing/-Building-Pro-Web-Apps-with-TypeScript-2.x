
export class Guid {
    public static readonly GUID_FORMAT: string = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx";
    public static newGuid() {
        return Guid.GUID_FORMAT.replace(/[xy]/g, (char: string) => {
            const randomChar = Math.random() * 16 | 0;
            const v = (char === "x") ? randomChar : (randomChar & 0x3 | 0x8);
            return v.toString(16);
        });
    }
}