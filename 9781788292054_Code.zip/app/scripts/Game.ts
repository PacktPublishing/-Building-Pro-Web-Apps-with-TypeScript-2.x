import { IWord } from "word/IWord";
import { ObjectWithoutSound } from "word/ObjectWithoutSound";
import { ObjectWithSound } from "word/ObjectWithSound";
import { Vehicule } from "word/Vehicule";
import { IWordContext, IFlashCardContext } from "word/IWordContext";
import * as _ from "lodash";
import { validatenotnull, notnull } from "./devutility/Decorators";

type CommandType = "start" | "reset";
export class Game {
    protected allWords: IWord[] = [];
    protected currentWordsIndex: number = 0;


    public onGameChanged: (wordContext: IFlashCardContext) => void;
    public onGameStarted: () => void;
    public onGameEnded: () => void;

    public constructor() {

    }

    private reset = (): void => {
        this.currentWordsIndex = 0;
    }

    public startNewGame(words: IWord[]): void {
        this.addWords(...words);
        this.reset();
    }

    public addWords(...words: IWord[]): void {
        this.allWords.push(...words);
        this.notifyGameChange();
    }

    protected notifyGameChange(): void {
        this.onGameChanged(this.buildGameContext(this.currentWord()));
    }
    private currentWord(): IWord {
        return this.allWords[this.currentWordsIndex];
    }

    @validatenotnull
    public buildGameContext(@notnull word: IWord): IFlashCardContext {
        const maxWordsCount = this.allWords.length;
        return {
            word: word,
            currentWordPosition: this.currentWordsIndex + 1,
            totalNumberOfWord: maxWordsCount,
            previousWord: () => this.previousWord(),
            nextWord: () => this.nextWord(),
            isPreviousButtonEnabled: this.currentWordsIndex !== 0,
            isNextButtonEnabled: this.currentWordsIndex !== maxWordsCount - 1,
            toggleFavorite: null,
            isFavorited: () => false
        } as IFlashCardContext;
    }

    public nextWord(): void {
        this.currentWordsIndex = this.getNextWord(this.currentWordsIndex);
        if (this.currentWordsIndex >= this.allWords.length) {
            this.onGameEnded();
        } else {
            this.notifyGameChange();
        }

    }

    public previousWord(): void {
        this.currentWordsIndex = this.getPreviousWord(this.currentWordsIndex);
        if (this.currentWordsIndex < 0) {
            this.onGameStarted();
        } else {
            this.notifyGameChange();
        }
    }

    protected getNextWord(currentIndex: number): number {
        return currentIndex + 1;
    }

    protected getPreviousWord(currentIndex: number): number {
        return currentIndex - 1;
    }

    public addWord(word: IWord): void;
    public addWord(word: ObjectWithSound): void;
    public addWord(word: IWord | ObjectWithSound): void {
        if (word instanceof Vehicule) {
            if (word.numberOfWheel < 0) {
                word.numberOfWheel = 0;
            }
        }
        this.allWords.push(word);
        this.notifyGameChange();
    }

    public static getName(): string {
        return Game.toString();
    }
    
    public executeCommand(command: CommandType, args?: any): void {
        switch (command) {
            case "start":
                this.startNewGame(args);
                break;
            case "reset":
                this.reset();
                break;
            default:
                console.log("Command action not defined");
        }
    }
}